
node app.js

API End Points

http://localhost:3000/cer/cer5
http://localhost:3000/cer/cer17
http://localhost:3000/cer/cer32

http://localhost:3000/sscp/sscp5
http://localhost:3000/sscp/sscp17
http://localhost:3000/sscp/sscp32



http://localhost:3000/download/sscp/numbering
http://localhost:3000/download/sscp/settings
http://localhost:3000/download/sscp/styles
http://localhost:3000/download/sscp/theme1

http://localhost:3000/download/cer/theme1
http://localhost:3000/download/cer/theme1
http://localhost:3000/download/cer/theme1
http://localhost:3000/download/cer/theme1