export class Article {
    votes: number;
    title: string;
    link: string;

    constructor(title: string, link: string, votes?: number) {
        this.title = title;
        this.link = link;
        this.votes = votes || 0;
    }

    voteUp(): void {
        this.votes += 1;
    }

    voteDown(): void {
        this.votes -= 1;

    }

    domain(): string {
        try {
            // e.g. http://foo.com/path/to/bar
            const domainAndPath: string = this.link.split('//')[1];
            // e.g. foo.com/path/to/bar
            return domainAndPath.split('/')[0];
        }catch (err) {
            return null;
        }
    }

}

/**
 * Here we are creating a new class that represents an Article.
 * Note that this is a plain class and not an Angular component.
 * In the Model-View-Controller pattern this would be the Model.
 * Each article has a title, a link, and a total for the votes.
 * When creating a new article we need the title and the link.
 * The votes parameter is optional (denoted by the ? at the end of the name) and defaults to zero.
 */