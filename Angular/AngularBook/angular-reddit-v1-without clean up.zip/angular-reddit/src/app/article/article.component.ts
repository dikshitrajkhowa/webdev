import { Component, OnInit, HostBinding, Input } from '@angular/core';

import {Article} from './article.model';

@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.css']
})
export class ArticleComponent implements OnInit {

  @HostBinding('attr.class') cssClass = 'row';

  // votes: number;
  // title: string;
  // link: string;

  // article : Article;
  @Input() article:Article;

  constructor() {
    // this.title = 'Angular';
    // this.link = 'http://angular.io';
    // this.votes = 10;

    //this.article = new Article('Angular' ,'http://angular.io',10); //The problem here is that we’ve hard coded a particular Article in the constructor
    // article is populated by the Input now, so we dont need anything here
  }

   voteUp(){
    //  this.votes +=1;
    // this.article.votes+=1;
    this.article.voteUp();
     return false; //else JS will propagate the event to its parents and the page will rerender
   }

   voteDown(){
    //  this.votes -=1;
    // this.article.votes -=1;
    this.article.voteDown();
     return false;
   }

  ngOnInit() {
  }

}
